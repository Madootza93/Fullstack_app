# NODE CRUD Website #
- Full website with auth login, cloud database, and content management system
- Uses Express with EJS Framework and Mongoose (MongoDB) database

```javascript
npm start
```